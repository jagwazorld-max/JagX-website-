/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['zigolwmewrjvmlrekrbw.supabase.co'],
  },
  experimental: {
    serverComponentsExternalPackages: ['@supabase/supabase-js'],
  },
}

module.exports = nextConfig
