export type UserRole = 'buyer' | 'seller' | 'browser' | 'admin'

export type ListingStatus = 'available' | 'sold' | 'pending'

export type ListingCategory =
  | 'E-Commerce'
  | 'Education'
  | 'Portfolio'
  | 'Blog'
  | 'Restaurant'
  | 'Religious'
  | 'Real Estate'
  | 'Healthcare'
  | 'Business'
  | 'Other'

export interface Profile {
  id: string
  full_name: string
  email: string
  phone: string | null
  role: UserRole
  avatar_url: string | null
  is_verified_seller: boolean
  seller_expires_at: string | null
  created_at: string
}

export interface Listing {
  id: string
  seller_id: string
  title: string
  description: string
  price: number
  category: ListingCategory
  tech_stack: string
  demo_url: string | null
  status: ListingStatus
  screenshots: string[]
  features: string[]
  views: number
  rating: number
  review_status: 'pending' | 'approved' | 'rejected'
  created_at: string
  seller?: Profile
}

export interface Message {
  id: string
  chat_id: string
  sender_id: string
  content: string
  created_at: string
  sender?: Profile
}

export interface Chat {
  id: string
  listing_id: string
  buyer_id: string
  seller_id: string
  last_message: string | null
  last_message_at: string | null
  created_at: string
  listing?: Listing
  buyer?: Profile
  seller?: Profile
  messages?: Message[]
  unread_count?: number
}

export interface PaymentProof {
  id: string
  user_id: string
  receipt_url: string
  bank: string
  amount: number
  status: 'pending' | 'approved' | 'rejected'
  created_at: string
  user?: Profile
}

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile
        Insert: Omit<Profile, 'created_at'>
        Update: Partial<Omit<Profile, 'id' | 'created_at'>>
      }
      listings: {
        Row: Listing
        Insert: Omit<Listing, 'id' | 'created_at' | 'views' | 'rating'>
        Update: Partial<Omit<Listing, 'id' | 'created_at'>>
      }
      messages: {
        Row: Message
        Insert: Omit<Message, 'id' | 'created_at'>
        Update: never
      }
      chats: {
        Row: Chat
        Insert: Omit<Chat, 'id' | 'created_at'>
        Update: Partial<Omit<Chat, 'id' | 'created_at'>>
      }
      payment_proofs: {
        Row: PaymentProof
        Insert: Omit<PaymentProof, 'id' | 'created_at'>
        Update: Partial<Omit<PaymentProof, 'id' | 'created_at'>>
      }
    }
  }
}
