import { Suspense } from 'react'
import { createClient } from '@/lib/supabase/server'
import HomeClient from '@/components/sections/HomeClient'

export default async function HomePage() {
  const supabase = createClient()

  // Fetch featured approved listings (SSR)
  const { data: listings } = await supabase
    .from('listings')
    .select('*, seller:profiles(full_name, avatar_url)')
    .eq('review_status', 'approved')
    .eq('status', 'available')
    .order('created_at', { ascending: false })
    .limit(8)

  const { data: { user } } = await supabase.auth.getUser()

  return (
    <Suspense fallback={<div className="min-h-screen bg-[#050B05]" />}>
      <HomeClient listings={listings || []} user={user} />
    </Suspense>
  )
}
