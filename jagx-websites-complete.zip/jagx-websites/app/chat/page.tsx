'use client'

import { useState, useRef, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Send, Search, ArrowLeft } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'
import { useChats, useRealtimeChat } from '@/hooks/useRealtimeChat'
import Navbar from '@/components/layout/Navbar'
import { formatDistanceToNow } from 'date-fns'

export default function ChatPage() {
  const { user, profile } = useAuth()
  const { chats, loading: chatsLoading } = useChats(user?.id ?? null)
  const [activeChatId, setActiveChatId] = useState<string | null>(null)
  const [msg, setMsg] = useState('')
  const [showSidebar, setShowSidebar] = useState(true)
  const msgEndRef = useRef<HTMLDivElement>(null)

  const activeChat = chats.find(c => c.id === activeChatId)
  const { messages, loading: msgsLoading, sendMessage } = useRealtimeChat(activeChatId)

  // Select first chat by default
  useEffect(() => {
    if (chats.length > 0 && !activeChatId) {
      setActiveChatId(chats[0].id)
    }
  }, [chats, activeChatId])

  // Scroll to bottom on new messages
  useEffect(() => {
    msgEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSend = async () => {
    if (!msg.trim() || !user) return
    await sendMessage(msg, user.id)
    setMsg('')
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center" style={{ background:'var(--black)' }}>
        <div className="card p-12 text-center max-w-sm">
          <div className="text-5xl mb-4">🔐</div>
          <h2 className="font-syne font-bold text-xl mb-3">Login Required</h2>
          <p className="text-muted text-sm mb-6">Please log in to access your messages.</p>
          <a href="/auth/login">
            <button className="btn-primary w-full justify-center">Login</button>
          </a>
        </div>
      </div>
    )
  }

  const otherUser = (chat: typeof activeChat) => {
    if (!chat || !profile) return null
    return profile.id === chat.buyer_id ? chat.seller : chat.buyer
  }

  return (
    <div className="flex h-screen" style={{ background:'var(--black)', paddingTop:68 }}>
      <Navbar />

      {/* Chats Sidebar */}
      <AnimatePresence>
        {showSidebar && (
          <motion.div initial={{ x:-300, opacity:0 }} animate={{ x:0, opacity:1 }}
            exit={{ x:-300, opacity:0 }} transition={{ type:'spring', stiffness:300, damping:30 }}
            className="flex flex-col flex-shrink-0"
            style={{ width:290, borderRight:'1px solid var(--border)', background:'var(--surface)' }}>

            <div className="p-4 border-b" style={{ borderColor:'var(--border)' }}>
              <h2 className="font-syne font-bold text-lg mb-3">Messages</h2>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={14} />
                <input className="input-field pl-9 text-sm" style={{ padding:'10px 14px 10px 34px' }}
                  placeholder="Search..." />
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {chatsLoading ? (
                <div className="p-4 space-y-3">
                  {[...Array(5)].map((_,i)=>(
                    <div key={i} style={{ height:70, background:'var(--card)', borderRadius:12 }} />
                  ))}
                </div>
              ) : chats.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="text-4xl mb-3">💬</div>
                  <div className="text-muted text-sm">No conversations yet</div>
                </div>
              ) : (
                chats.map(chat => {
                  const other = profile?.id === chat.buyer_id ? chat.seller : chat.buyer
                  const isActive = chat.id === activeChatId
                  return (
                    <div key={chat.id} onClick={() => { setActiveChatId(chat.id); setShowSidebar(window.innerWidth > 768) }}
                      className="cursor-pointer transition-all duration-200"
                      style={{
                        padding:'14px 16px',
                        borderBottom:'1px solid var(--border)',
                        background: isActive ? 'rgba(34,197,94,0.08)' : 'transparent',
                        borderLeft: `3px solid ${isActive ? '#22C55E' : 'transparent'}`,
                      }}>
                      <div className="flex items-center gap-3">
                        <div className="relative flex-shrink-0">
                          <div style={{ width:42, height:42, borderRadius:'50%',
                            background:'linear-gradient(135deg,#22C55E,#F5A623)',
                            display:'flex', alignItems:'center', justifyContent:'center',
                            fontWeight:800, fontSize:15 }}>
                            {other?.full_name?.[0]?.toUpperCase() ?? '?'}
                          </div>
                          <div style={{ position:'absolute', bottom:0, right:0, width:12, height:12,
                            borderRadius:'50%', background:'#22C55E',
                            border:'2px solid var(--surface)' }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-center">
                            <span className="font-bold text-sm">{other?.full_name ?? 'User'}</span>
                            {chat.last_message_at && (
                              <span className="text-[11px] text-muted">
                                {formatDistanceToNow(new Date(chat.last_message_at), { addSuffix: false })}
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-muted truncate opacity-60">
                            {chat.listing?.title}
                          </div>
                          <div className="text-xs text-muted truncate mt-0.5">
                            {chat.last_message ?? 'Start a conversation'}
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Chat Area */}
      <div className="flex flex-col flex-1 min-w-0">
        {activeChatId && activeChat ? (
          <>
            {/* Chat header */}
            <div className="flex items-center justify-between px-5 py-3.5"
              style={{ borderBottom:'1px solid var(--border)', background:'var(--surface)' }}>
              <div className="flex items-center gap-3">
                <button onClick={() => setShowSidebar(true)} className="lg:hidden mr-1">
                  <ArrowLeft size={20} className="text-muted" />
                </button>
                <div style={{ width:42, height:42, borderRadius:'50%',
                  background:'linear-gradient(135deg,#22C55E,#F5A623)',
                  display:'flex', alignItems:'center', justifyContent:'center',
                  fontWeight:800 }}>
                  {otherUser(activeChat)?.full_name?.[0]?.toUpperCase() ?? '?'}
                </div>
                <div>
                  <div className="font-bold">{otherUser(activeChat)?.full_name}</div>
                  <div className="text-xs text-muted">
                    Re: {activeChat.listing?.title ?? 'Listing'}
                    <span className="ml-2 text-green-500">● Online</span>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-gold font-bold text-sm">
                  ₦{activeChat.listing?.price?.toLocaleString()}
                </div>
                <div className="text-xs text-muted">{activeChat.listing?.category}</div>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-5 space-y-4">
              {msgsLoading ? (
                <div className="flex items-center justify-center h-full text-muted">
                  Loading messages...
                </div>
              ) : messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <div className="text-5xl mb-3">👋</div>
                  <div className="font-bold mb-1">Start the conversation</div>
                  <div className="text-muted text-sm">
                    Say hi to {otherUser(activeChat)?.full_name}!
                  </div>
                </div>
              ) : (
                <>
                  <AnimatePresence initial={false}>
                    {messages.map((m, i) => {
                      const isMe = m.sender_id === user.id
                      return (
                        <motion.div key={m.id}
                          initial={{ opacity:0, y:12 }} animate={{ opacity:1, y:0 }}
                          transition={{ duration:0.2 }}
                          className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                          <div>
                            {!isMe && (
                              <div className="flex items-center gap-1.5 mb-1">
                                <div style={{ width:20, height:20, borderRadius:'50%',
                                  background:'#22C55E', display:'flex', alignItems:'center',
                                  justifyContent:'center', fontSize:9, fontWeight:800 }}>
                                  {m.sender?.full_name?.[0]?.toUpperCase()}
                                </div>
                                <span className="text-[11px] text-muted">{m.sender?.full_name}</span>
                              </div>
                            )}
                            <div className={isMe ? 'bubble-me' : 'bubble-them'}>{m.content}</div>
                            <div className={`text-[10px] text-muted mt-1 ${isMe ? 'text-right' : 'text-left'}`}>
                              {new Date(m.created_at).toLocaleTimeString('en-NG',{hour:'2-digit',minute:'2-digit'})}
                            </div>
                          </div>
                        </motion.div>
                      )
                    })}
                  </AnimatePresence>
                  <div ref={msgEndRef} />
                </>
              )}
            </div>

            {/* Input */}
            <div className="flex gap-3 p-4 items-center"
              style={{ borderTop:'1px solid var(--border)', background:'var(--surface)' }}>
              <input className="input-field flex-1"
                placeholder="Type a message… (Enter to send)"
                value={msg} onChange={e => setMsg(e.target.value)}
                onKeyDown={e => e.key==='Enter' && !e.shiftKey && handleSend()} />
              <button className="btn-primary flex-shrink-0" style={{ padding:'13px 20px' }}
                onClick={handleSend} disabled={!msg.trim()}>
                <Send size={16} />
              </button>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-center p-8">
            <div className="text-6xl mb-4">💬</div>
            <h2 className="font-syne font-bold text-xl mb-2">Your Messages</h2>
            <p className="text-muted text-sm max-w-xs">
              Select a conversation from the sidebar, or start one by viewing a listing.
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
