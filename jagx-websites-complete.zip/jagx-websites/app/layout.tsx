import type { Metadata } from 'next'
import { Syne, Outfit } from 'next/font/google'
import './globals.css'

const syne = Syne({
  subsets: ['latin'],
  variable: '--font-syne',
  display: 'swap',
  weight: ['400','600','700','800'],
})

const outfit = Outfit({
  subsets: ['latin'],
  variable: '--font-outfit',
  display: 'swap',
  weight: ['300','400','500','600','700'],
})

export const metadata: Metadata = {
  title: 'JagX Websites — Nigeria\'s #1 Website Marketplace',
  description: 'Buy and sell premium ready-made websites for Nigerian businesses. Pay in Naira. Launch in 24 hours. Developed by JRILISECE & JagX.',
  keywords: ['websites Nigeria', 'buy website Nigeria', 'sell website Nigeria', 'website marketplace', 'Naira', 'JagX'],
  authors: [{ name: 'JRILISECE & JagX' }],
  openGraph: {
    title: 'JagX Websites — Buy & Sell Premium Websites in Nigeria',
    description: 'Nigeria\'s premier marketplace for ready-made websites. 1200+ sold. Pay in Naira.',
    url: 'https://jagxwebsites.ng',
    siteName: 'JagX Websites',
    locale: 'en_NG',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'JagX Websites',
    description: 'Nigeria\'s #1 website marketplace. Buy. Sell. Grow.',
  },
  robots: { index: true, follow: true },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${syne.variable} ${outfit.variable}`}>
      <body className="bg-[#050B05] text-[#F0FDF4] font-outfit antialiased overflow-x-hidden">
        {children}
      </body>
    </html>
  )
}
