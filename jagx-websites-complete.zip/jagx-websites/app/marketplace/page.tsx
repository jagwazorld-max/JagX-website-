'use client'

import { useState, useEffect, useCallback } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, Filter, ChevronDown } from 'lucide-react'
import { getSupabase } from '@/lib/supabase/client'
import { useAuth } from '@/hooks/useAuth'
import type { Listing } from '@/types/database'
import ListingCard from '@/components/ui/ListingCard'
import Navbar from '@/components/layout/Navbar'

const CATEGORIES = ['All','E-Commerce','Education','Portfolio','Blog','Restaurant','Religious','Real Estate','Healthcare']

export default function MarketplacePage() {
  const { user, profile } = useAuth()
  const [listings, setListings] = useState<Listing[]>([])
  const [loading, setLoading] = useState(true)
  const [cat, setCat] = useState('All')
  const [search, setSearch] = useState('')
  const [status, setStatus] = useState('all')
  const [sort, setSort] = useState('newest')
  const supabase = getSupabase()

  const fetchListings = useCallback(async () => {
    setLoading(true)
    let query = supabase
      .from('listings')
      .select('*, seller:profiles(full_name, avatar_url)')
      .eq('review_status', 'approved')

    if (cat !== 'All') query = query.eq('category', cat)
    if (status !== 'all') query = query.eq('status', status)
    if (search) query = query.ilike('title', `%${search}%`)
    if (sort === 'newest') query = query.order('created_at', { ascending: false })
    else if (sort === 'price-low') query = query.order('price', { ascending: true })
    else if (sort === 'price-high') query = query.order('price', { ascending: false })

    const { data } = await query
    setListings(data as Listing[] || [])
    setLoading(false)
  }, [cat, search, status, sort, supabase])

  useEffect(() => { fetchListings() }, [fetchListings])

  // Real-time: new listing goes live instantly
  useEffect(() => {
    const channel = supabase
      .channel('public-listings')
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'listings', filter: "review_status=eq.approved" },
        () => fetchListings()
      )
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'listings' },
        () => fetchListings()
      )
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [fetchListings, supabase])

  const visibleListings = user ? listings : listings.slice(0, 2)

  return (
    <div className="min-h-screen" style={{ background: 'var(--black)' }}>
      <Navbar />
      <div className="max-w-7xl mx-auto px-5 pt-28 pb-20">

        {/* Header */}
        <motion.div initial={{ opacity:0, y:24 }} animate={{ opacity:1, y:0 }} className="mb-10">
          <span className="badge badge-green mb-4">🛒 Marketplace</span>
          <h1 className="section-title mb-3">
            Browse <span className="gradient-text">Premium Websites</span>
          </h1>
          <p className="text-muted text-base">
            {user
              ? `${listings.length} listings available for Nigerian businesses.`
              : '⚠️ Register to see all listings and contact sellers.'}
          </p>
        </motion.div>

        {/* Search + filters */}
        <div className="flex flex-wrap gap-3 mb-6">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted" size={16} />
            <input className="input-field pl-11"
              placeholder="Search websites..."
              value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="input-field w-auto min-w-[150px]"
            value={status} onChange={e => setStatus(e.target.value)}>
            <option value="all">All Status</option>
            <option value="available">Available</option>
            <option value="sold">Sold Out</option>
          </select>
          <select className="input-field w-auto min-w-[165px]"
            value={sort} onChange={e => setSort(e.target.value)}>
            <option value="newest">Newest First</option>
            <option value="price-low">Price: Low → High</option>
            <option value="price-high">Price: High → Low</option>
          </select>
        </div>

        {/* Category tabs */}
        <div className="flex gap-2 overflow-x-auto pb-2 mb-9 scrollbar-hide">
          {CATEGORIES.map(c => (
            <button key={c} onClick={() => setCat(c)}
              className={`flex-shrink-0 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all duration-200 border
                ${cat===c ? 'bg-green text-white border-green' : 'text-muted border-transparent hover:border-green hover:text-green'}`}
              style={{ background: cat===c ? '#22C55E' : 'transparent', color: cat===c ? '#fff' : undefined }}>
              {c}
            </button>
          ))}
        </div>

        {/* Listing grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {[...Array(8)].map((_,i) => (
              <div key={i} className="card" style={{ height:320 }}>
                <div style={{ height:160, background:'var(--surface)' }}
                  className="shimmer-pulse" />
                <div className="p-5 space-y-3">
                  {[80,60,40].map(w => (
                    <div key={w} style={{ height:10, width:`${w}%`,
                      background:'var(--border)', borderRadius:4 }} />
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <AnimatePresence mode="popLayout">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {visibleListings.map((l, i) => (
                <motion.div key={l.id}
                  initial={{ opacity:0, y:24, scale:0.97 }}
                  animate={{ opacity:1, y:0, scale:1 }}
                  transition={{ delay: i * 0.06, duration:0.45, ease:[.16,1,.3,1] }}>
                  <ListingCard listing={l} />
                </motion.div>
              ))}

              {/* Lock cards for unauthenticated */}
              {!user && [...Array(4)].map((_,i) => (
                <motion.div key={`lock-${i}`}
                  initial={{ opacity:0 }} animate={{ opacity:1 }}
                  transition={{ delay: (i+2) * 0.06 }}
                  className="card overflow-hidden relative" style={{ minHeight:300 }}>
                  <div style={{ filter:'blur(10px)', opacity:0.25, pointerEvents:'none', userSelect:'none' }}>
                    <div style={{ height:160, background:'var(--surface)' }} />
                    <div className="p-5 space-y-2">
                      {[80,55,40].map(w=><div key={w} style={{height:10,width:`${w}%`,background:'var(--border)',borderRadius:4}}/>)}
                    </div>
                  </div>
                  <div className="absolute inset-0 flex flex-col items-center justify-center"
                    style={{ background:'rgba(5,11,5,0.72)', backdropFilter:'blur(3px)' }}>
                    <div className="text-4xl mb-3">🔒</div>
                    <div className="font-bold mb-3">Register to View</div>
                    <a href="/auth/signup">
                      <button className="btn-primary text-sm" style={{ padding:'10px 22px' }}>
                        Sign Up Free
                      </button>
                    </a>
                  </div>
                </motion.div>
              ))}

              {user && listings.length === 0 && (
                <div className="col-span-full text-center py-20">
                  <div className="text-5xl mb-4">🔍</div>
                  <div className="font-bold text-lg mb-2">No listings found</div>
                  <div className="text-muted text-sm">Try adjusting your filters</div>
                </div>
              )}
            </div>
          </AnimatePresence>
        )}

        {/* Seller CTA */}
        {user && profile?.role === 'seller' && !profile.is_verified_seller && (
          <motion.div initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }}
            className="text-center mt-16">
            <div className="card inline-block px-16 py-10">
              <div className="text-5xl mb-3">💼</div>
              <div className="font-syne font-bold text-xl mb-2">Start Selling on JagX</div>
              <div className="text-muted text-sm mb-5">List your website for ₦2,000 · Valid 6 months</div>
              <a href="/seller/pay">
                <button className="btn-gold">Pay ₦2,000 & Start Selling</button>
              </a>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  )
}
