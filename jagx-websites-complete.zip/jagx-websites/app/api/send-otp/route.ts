import { NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: Request) {
  const { email, otp, name } = await req.json()

  if (!email || !otp) {
    return NextResponse.json({ error: 'Missing email or otp' }, { status: 400 })
  }

  const { data, error } = await resend.emails.send({
    from: 'JagX Websites <noreply@jagxwebsites.ng>',
    to: email,
    subject: `${otp} — Your JagX Verification Code`,
    html: `
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
</head>
<body style="margin:0;padding:0;background:#050B05;font-family:'Outfit',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#050B05;padding:40px 20px;">
    <tr><td align="center">
      <table width="520" cellpadding="0" cellspacing="0" style="background:#0C180C;border:1px solid rgba(34,197,94,0.2);border-radius:24px;overflow:hidden;">
        <!-- Header -->
        <tr><td style="background:linear-gradient(135deg,#0C180C,#111D11);padding:40px;text-align:center;border-bottom:1px solid rgba(34,197,94,0.15);">
          <div style="width:60px;height:60px;background:linear-gradient(135deg,#22C55E,#16A34A);border-radius:16px;display:inline-flex;align-items:center;justify-content:center;font-size:28px;font-weight:900;color:#fff;margin-bottom:16px;">J</div>
          <h1 style="margin:0;color:#F0FDF4;font-size:26px;font-weight:800;letter-spacing:-0.5px;">JagX Websites</h1>
          <p style="margin:8px 0 0;color:#86EFAC;font-size:14px;">Nigeria's Premier Website Marketplace</p>
        </td></tr>
        <!-- Body -->
        <tr><td style="padding:48px 40px;text-align:center;">
          <p style="margin:0 0 8px;color:#86EFAC;font-size:14px;text-transform:uppercase;letter-spacing:1px;">Hello ${name || 'there'}! Your verification code is</p>
          <div style="background:rgba(34,197,94,0.08);border:2px solid rgba(34,197,94,0.3);border-radius:16px;padding:28px 20px;margin:24px 0;display:inline-block;min-width:240px;">
            <span style="font-size:48px;font-weight:900;letter-spacing:12px;color:#22C55E;font-family:monospace;">${otp}</span>
          </div>
          <p style="color:#86EFAC;font-size:14px;line-height:1.7;margin:0;">
            This code expires in <strong style="color:#F5A623;">10 minutes</strong>.<br/>
            Never share this code with anyone.
          </p>
        </td></tr>
        <!-- Footer -->
        <tr><td style="padding:24px 40px;border-top:1px solid rgba(34,197,94,0.1);text-align:center;">
          <p style="margin:0;color:rgba(134,239,172,0.4);font-size:12px;line-height:1.6;">
            © 2025 JagX Websites · Developed by JRILISECE & JagX<br/>
            🇳🇬 Nigeria's #1 Website Marketplace
          </p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
    `,
  })

  if (error) {
    console.error('Email send error:', error)
    return NextResponse.json({ error: 'Failed to send email' }, { status: 500 })
  }

  return NextResponse.json({ success: true, id: data?.id })
}
