import { NextResponse } from 'next/server'
import { Resend } from 'resend'
import { createClient } from '@/lib/supabase/server'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: Request) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json()
  const { receipt_url, bank } = body

  // Save to database
  const { data: proof, error } = await supabase
    .from('payment_proofs')
    .insert({ user_id: user.id, receipt_url, bank, amount: 2000 })
    .select()
    .single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Notify admin
  await resend.emails.send({
    from: 'JagX System <noreply@jagxwebsites.ng>',
    to: process.env.ADMIN_EMAIL!,
    subject: '💰 New Seller Payment Proof — Action Required',
    html: `
<div style="font-family:Arial,sans-serif;background:#050B05;padding:32px;color:#F0FDF4;border-radius:16px;">
  <h2 style="color:#F5A623;">💰 New Payment Proof Submitted</h2>
  <p style="color:#86EFAC;">A seller has submitted a payment proof for review.</p>
  <table style="border-collapse:collapse;width:100%;margin:20px 0;">
    <tr><td style="padding:10px;color:#86EFAC;font-weight:600;">User ID:</td><td style="padding:10px;color:#fff;font-size:12px;font-family:monospace;">${user.id}</td></tr>
    <tr><td style="padding:10px;color:#86EFAC;font-weight:600;">Email:</td><td style="padding:10px;color:#22C55E;">${user.email}</td></tr>
    <tr><td style="padding:10px;color:#86EFAC;font-weight:600;">Bank:</td><td style="padding:10px;color:#fff;">${bank}</td></tr>
    <tr><td style="padding:10px;color:#86EFAC;font-weight:600;">Amount:</td><td style="padding:10px;color:#F5A623;font-weight:700;">₦2,000</td></tr>
    <tr><td style="padding:10px;color:#86EFAC;font-weight:600;">Receipt:</td><td style="padding:10px;"><a href="${receipt_url}" style="color:#22C55E;">View Receipt</a></td></tr>
  </table>
  <p style="color:#86EFAC;">Login to your admin dashboard to approve or reject this request.</p>
  <a href="${process.env.NEXT_PUBLIC_APP_URL}/admin" style="display:inline-block;background:linear-gradient(135deg,#22C55E,#16A34A);color:#fff;padding:12px 28px;border-radius:10px;text-decoration:none;font-weight:700;">Go to Admin Panel</a>
</div>
    `,
  })

  return NextResponse.json({ success: true, proof })
}
