import { NextResponse } from 'next/server'
import { Resend } from 'resend'

const resend = new Resend(process.env.RESEND_API_KEY)

export async function POST(req: Request) {
  const { name, email, subject, message } = await req.json()

  const { data, error } = await resend.emails.send({
    from: 'JagX Contact <noreply@jagxwebsites.ng>',
    to: process.env.CONTACT_EMAIL!,
    replyTo: email,
    subject: `[JagX Contact] ${subject}`,
    html: `
<div style="font-family:Arial,sans-serif;background:#050B05;padding:32px;color:#F0FDF4;border-radius:16px;">
  <h2 style="color:#22C55E;margin-bottom:24px;">New Contact Form Submission</h2>
  <table style="width:100%;border-collapse:collapse;">
    <tr><td style="padding:12px;color:#86EFAC;font-weight:600;width:120px;">Name:</td><td style="padding:12px;color:#F0FDF4;">${name}</td></tr>
    <tr><td style="padding:12px;color:#86EFAC;font-weight:600;">Email:</td><td style="padding:12px;"><a href="mailto:${email}" style="color:#22C55E;">${email}</a></td></tr>
    <tr><td style="padding:12px;color:#86EFAC;font-weight:600;">Subject:</td><td style="padding:12px;color:#F0FDF4;">${subject}</td></tr>
    <tr><td style="padding:12px;color:#86EFAC;font-weight:600;vertical-align:top;">Message:</td><td style="padding:12px;color:#F0FDF4;line-height:1.7;">${message.replace(/\n/g,'<br/>')}</td></tr>
  </table>
  <p style="margin-top:24px;color:rgba(134,239,172,0.4);font-size:12px;">Sent via JagX Websites · jagxwebsites.ng</p>
</div>
    `,
  })

  if (error) return NextResponse.json({ error: 'Failed' }, { status: 500 })
  return NextResponse.json({ success: true })
}
