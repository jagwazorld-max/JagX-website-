'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { getSupabase } from '@/lib/supabase/client'
import type { Message, Chat } from '@/types/database'

export function useRealtimeChat(chatId: string | null) {
  const [messages, setMessages] = useState<Message[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = getSupabase()
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)

  // Fetch existing messages
  const fetchMessages = useCallback(async () => {
    if (!chatId) return
    setLoading(true)
    const { data, error } = await supabase
      .from('messages')
      .select('*, sender:profiles(*)')
      .eq('chat_id', chatId)
      .order('created_at', { ascending: true })

    if (!error && data) setMessages(data as Message[])
    setLoading(false)
  }, [chatId, supabase])

  // Subscribe to new messages in real time
  useEffect(() => {
    if (!chatId) return
    fetchMessages()

    // Remove old channel if chatId changes
    if (channelRef.current) {
      supabase.removeChannel(channelRef.current)
    }

    const channel = supabase
      .channel(`chat:${chatId}`)
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `chat_id=eq.${chatId}`,
        },
        async (payload) => {
          // Fetch sender profile for the new message
          const { data: sender } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', payload.new.sender_id)
            .single()

          setMessages((prev) => [
            ...prev,
            { ...payload.new, sender } as Message,
          ])
        }
      )
      .subscribe()

    channelRef.current = channel

    return () => {
      supabase.removeChannel(channel)
    }
  }, [chatId, fetchMessages, supabase])

  const sendMessage = useCallback(
    async (content: string, senderId: string) => {
      if (!chatId || !content.trim()) return null

      const { data, error } = await supabase
        .from('messages')
        .insert({ chat_id: chatId, sender_id: senderId, content })
        .select()
        .single()

      if (error) console.error('Send message error:', error)
      return data
    },
    [chatId, supabase]
  )

  return { messages, loading, sendMessage }
}

// Hook for listing all chats for a user
export function useChats(userId: string | null) {
  const [chats, setChats] = useState<Chat[]>([])
  const [loading, setLoading] = useState(true)
  const supabase = getSupabase()

  useEffect(() => {
    if (!userId) { setLoading(false); return }

    const fetchChats = async () => {
      const { data, error } = await supabase
        .from('chats')
        .select(`
          *,
          listing:listings(id, title, price, category),
          buyer:profiles!chats_buyer_id_fkey(id, full_name, avatar_url),
          seller:profiles!chats_seller_id_fkey(id, full_name, avatar_url)
        `)
        .or(`buyer_id.eq.${userId},seller_id.eq.${userId}`)
        .order('last_message_at', { ascending: false })

      if (!error && data) setChats(data as Chat[])
      setLoading(false)
    }

    fetchChats()

    // Real-time: update chat list when last_message changes
    const channel = supabase
      .channel(`chats:${userId}`)
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'chats' },
        () => fetchChats()
      )
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [userId, supabase])

  return { chats, loading }
}
