/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        syne:   ['Syne', 'sans-serif'],
        outfit: ['Outfit', 'sans-serif'],
      },
      colors: {
        black:   '#050B05',
        surface: '#0C180C',
        card:    '#101E10',
        green: {
          DEFAULT: '#22C55E',
          dark:    '#16A34A',
        },
        gold: {
          DEFAULT: '#F5A623',
          dark:    '#D4861A',
        },
        muted: '#86EFAC',
      },
      animation: {
        'float':       'float 7s ease-in-out infinite',
        'float-b':     'floatB 9s ease-in-out infinite 1.5s',
        'float-c':     'float 8s ease-in-out infinite 3s',
        'pulse-glow':  'pulseGlow 3s ease-in-out infinite',
        'ticker':      'ticker 22s linear infinite',
        'spin-slow':   'spin 22s linear infinite',
        'blob':        'blob 8s ease-in-out infinite',
        'slide-up':    'slideUp 0.65s cubic-bezier(.16,1,.3,1) forwards',
        'bounce-in':   'bounceIn 0.65s cubic-bezier(.36,.07,.19,.97) forwards',
        'shimmer':     'shimmer 2s ease-in-out infinite',
        'ping-slow':   'ping 1.5s ease infinite',
        'sidebar-in':  'sidebarIn 0.32s cubic-bezier(.16,1,.3,1)',
        'overlay-in':  'overlayIn 0.25s ease',
      },
      keyframes: {
        float:      { '0%,100%': { transform:'translateY(0) rotate(0deg)' }, '33%': { transform:'translateY(-18px) rotate(1.5deg)' }, '66%': { transform:'translateY(-8px) rotate(-1deg)' } },
        floatB:     { '0%,100%': { transform:'translateY(0) rotate(0deg) scale(1)' }, '50%': { transform:'translateY(-22px) rotate(-2deg) scale(1.02)' } },
        pulseGlow:  { '0%,100%': { boxShadow:'0 0 20px rgba(34,197,94,0.25)' }, '50%': { boxShadow:'0 0 60px rgba(34,197,94,0.55), 0 0 100px rgba(245,166,35,0.18)' } },
        ticker:     { '0%': { transform:'translateX(0)' }, '100%': { transform:'translateX(-50%)' } },
        blob:       { '0%,100%': { borderRadius:'60% 40% 30% 70%/60% 30% 70% 40%' }, '50%': { borderRadius:'30% 60% 70% 40%/50% 60% 30% 60%' } },
        slideUp:    { from: { opacity:'0', transform:'translateY(36px)' }, to: { opacity:'1', transform:'translateY(0)' } },
        bounceIn:   { '0%': { transform:'scale(0.4)', opacity:'0' }, '60%': { transform:'scale(1.12)' }, '80%': { transform:'scale(0.96)' }, '100%': { transform:'scale(1)', opacity:'1' } },
        shimmer:    { '0%': { transform:'translateX(-100%) skewX(-15deg)' }, '100%': { transform:'translateX(200%) skewX(-15deg)' } },
        sidebarIn:  { from: { transform:'translateX(-100%)' }, to: { transform:'translateX(0)' } },
        overlayIn:  { from: { opacity:'0' }, to: { opacity:'1' } },
      },
      backgroundImage: {
        'grid-pattern': "linear-gradient(rgba(34,197,94,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(34,197,94,0.08) 1px, transparent 1px)",
        'gradient-green-gold': 'linear-gradient(135deg, #22C55E, #F5A623)',
      },
      backgroundSize: {
        'grid': '64px 64px',
      },
    },
  },
  plugins: [],
}
